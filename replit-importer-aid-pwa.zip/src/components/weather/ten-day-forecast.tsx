import { CalendarDays, Droplets, Sun, Cloud, CloudSun, CloudRain, CloudDrizzle, CloudSnow, CloudLightning, CloudFog } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { DailyForecast, WeatherSource } from "@/types/weather";

interface TenDayForecastProps {
  dailyForecast: DailyForecast[];
  weatherSources: WeatherSource[];
  isImperial?: boolean;
}

export function TenDayForecast({ dailyForecast, weatherSources, isImperial = true }: TenDayForecastProps) {
  const getConditionIcon = (condition: string) => {
    const c = condition.toLowerCase();
    if (c.includes("thunder")) return <CloudLightning className="w-7 h-7 text-primary" />;
    if (c.includes("drizzle")) return <CloudDrizzle className="w-7 h-7 text-primary" />;
    if (c.includes("shower") || c.includes("rain")) return <CloudRain className="w-7 h-7 text-primary" />;
    if (c.includes("snow")) return <CloudSnow className="w-7 h-7 text-primary" />;
    if (c.includes("fog")) return <CloudFog className="w-7 h-7 text-primary" />;
    if (c.includes("partly") || c.includes("sun")) return <CloudSun className="w-7 h-7 text-primary" />;
    if (c.includes("cloud")) return <Cloud className="w-7 h-7 text-primary" />;
    return <Sun className="w-7 h-7 text-primary" />;
  };
  const sourceColors = {
    openweathermap: "bg-secondary",
    accuweather: "bg-accent", 
    weatherapi: "bg-primary"
  };

  const getSourceAbbreviation = (source: string) => {
    const abbrev = {
      openweathermap: "OWM",
      accuweather: "ACC",
      weatherapi: "API"
    };
    return abbrev[source as keyof typeof abbrev] || source.toUpperCase();
  };

  // Get the most accurate source for each day (simplified - just use most accurate overall)
  const mostAccurateSource = weatherSources.reduce((prev, current) => 
    (current.accuracy > prev.accuracy) ? current : prev
  );

  return (
    <section className="mb-8">
      <Card className="bg-white rounded-2xl shadow-lg border border-neutral-100">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold text-neutral-800 mb-6 flex items-center gap-2">
            <CalendarDays className="text-primary w-5 h-5" />
            10-Day Forecast
          </h2>

          <div className="space-y-2">
            {dailyForecast.map((day, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors border border-neutral-100"
              >
                <div className="flex items-center gap-3 flex-1">
                  <div className="text-sm text-neutral-600 font-medium w-16">
                    {day.day}
                  </div>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-200 to-blue-300 flex items-center justify-center">
                    {getConditionIcon(day.condition)}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-neutral-800">
                      {day.condition}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-xs text-neutral-500">
                    {day.precipitation}%
                  </div>
                  <div className="text-right min-w-[60px]">
                    <div className="text-lg font-semibold text-neutral-800">
                      {isImperial ? day.highTemp : Math.round((day.highTemp - 32) * 5/9)}°
                    </div>
                    <div className="text-sm text-neutral-500">
                      {isImperial ? day.lowTemp : Math.round((day.lowTemp - 32) * 5/9)}°
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
